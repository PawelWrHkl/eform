import { chromium } from "@playwright/test";
import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const root = process.cwd();
const config = JSON.parse(await fs.readFile(path.join(root, "config/efora.config.json"), "utf8"));
const models = JSON.parse(await fs.readFile(path.join(root, config.modelsFile), "utf8"));
const outputDir = path.join(root, "results");
const screenshotsDir = path.join(outputDir, "screenshots");
await fs.mkdir(screenshotsDir, { recursive: true });

const results = [];
const startedAt = new Date().toISOString();
const browser = await chromium.launch({ headless: config.headless });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
page.setDefaultTimeout(config.timeoutMs);

function numberFromPrice(text) {
  if (!text) return null;
  const cleaned = text.replace(/\s/g, "").replace(/[^0-9,.-]/g, "");
  if (!cleaned) return null;
  const lastComma = cleaned.lastIndexOf(",");
  const lastDot = cleaned.lastIndexOf(".");
  let normalized = cleaned;
  if (lastComma > lastDot) normalized = cleaned.replace(/\./g, "").replace(",", ".");
  else normalized = cleaned.replace(/,/g, "");
  const value = Number(normalized);
  return Number.isFinite(value) ? value : null;
}

function safeName(value) {
  return value.replace(/[^a-zA-Z0-9_-]+/g, "_").slice(0, 100);
}

async function screenshot(model, type) {
  const file = `${safeName(model.code)}_${type}_${Date.now()}.png`;
  await page.screenshot({ path: path.join(screenshotsDir, file), fullPage: true });
  return `screenshots/${file}`;
}

async function addIssue(model, type, message, details = {}) {
  results.push({
    status: "ERROR",
    priority: "P1",
    type,
    modelCode: model.code,
    modelName: model.name,
    url: page.url(),
    message,
    details,
    screenshot: await screenshot(model, type),
    detectedAt: new Date().toISOString()
  });
}

async function login() {
  const login = process.env.EFORA_LOGIN;
  const password = process.env.EFORA_PASSWORD;
  if (!login || !password) throw new Error("Ustaw EFORA_LOGIN i EFORA_PASSWORD w zmiennych środowiskowych.");
  await page.goto(new URL(config.loginPath, config.baseUrl).toString());
  await page.locator(config.selectors.login).fill(login);
  await page.locator(config.selectors.password).fill(password);
  await Promise.all([
    page.waitForLoadState("networkidle"),
    page.locator(config.selectors.loginSubmit).click()
  ]);
}

async function fieldName(field, index) {
  const label = field.locator(config.selectors.fieldLabel).first();
  if (await label.count()) return (await label.innerText()).trim();
  return (await field.getAttribute("data-field-name")) || `pole-${index + 1}`;
}

async function chooseFirstAvailable(field) {
  const select = field.locator(config.selectors.nativeSelect).first();
  if (await select.count()) {
    const values = await select.locator("option:not(:disabled)").evaluateAll(options =>
      options.map(o => ({ value: o.value, text: o.textContent?.trim() || "" }))
        .filter(o => o.value !== "" && o.text !== "")
    );
    if (!values.length) return { ok: false, reason: "Brak dostępnych pozycji na liście." };
    await select.selectOption(values[0].value);
    return { ok: true, selected: values[0].text };
  }

  const choices = field.locator(config.selectors.choice);
  const count = await choices.count();
  if (!count) return { ok: false, reason: "Brak dostępnych opcji do wybrania." };
  for (let i = 0; i < count; i++) {
    const choice = choices.nth(i);
    if (await choice.isVisible() && await choice.isEnabled()) {
      await choice.click();
      return { ok: true, selected: (await choice.getAttribute("value")) || (await choice.innerText().catch(() => "pierwsza opcja")) };
    }
  }
  return { ok: false, reason: "Wszystkie opcje są ukryte albo nieaktywne." };
}

async function readPrice(selector) {
  const locator = page.locator(selector).first();
  if (!await locator.count() || !await locator.isVisible()) return { text: "", value: null };
  const text = (await locator.innerText()).trim();
  return { text, value: numberFromPrice(text) };
}

async function verifyPrice(model, stage) {
  const actual = await readPrice(config.selectors.price);
  if (actual.value === null || actual.value <= 0) {
    await addIssue(model, "BRAK_CENY", `Brak prawidłowej ceny (${stage}).`, { displayedPrice: actual.text });
    return false;
  }
  if (typeof model.expectedMinPrice === "number" && actual.value < model.expectedMinPrice) {
    await addIssue(model, "CENA_ZANIZONA", `Cena Efora jest niższa od ceny wzorcowej (${stage}).`, {
      eforaPrice: actual.value,
      expectedMinPrice: model.expectedMinPrice,
      difference: Number((model.expectedMinPrice - actual.value).toFixed(2)),
      currency: model.currency
    });
    return false;
  }
  return true;
}

async function testModel(model) {
  const issueCountBefore = results.length;
  const selected = {};
  let completed = false;
  await page.goto(new URL(model.path, config.baseUrl).toString());
  await page.locator(config.selectors.configurator).waitFor({ state: "visible" });

  for (let step = 1; step <= config.maxSteps; step++) {
    const fields = page.locator(config.selectors.requiredField);
    const count = await fields.count();
    for (let i = 0; i < count; i++) {
      const field = fields.nth(i);
      if (!await field.isVisible()) continue;
      const name = await fieldName(field, i);
      const outcome = await chooseFirstAvailable(field);
      if (!outcome.ok) {
        await addIssue(model, "BRAK_OPCJI", "Konfigurator nie może przejść dalej, ponieważ wymagane pole nie ma opcji.", { step, field: name, reason: outcome.reason, selected });
        return;
      }
      selected[name] = outcome.selected;
      await page.waitForTimeout(150);
      await verifyPrice(model, `krok ${step}, pole ${name}`);
    }

    const addToCart = page.locator(config.selectors.addToCart).first();
    if (await addToCart.count() && await addToCart.isVisible()) {
      if (!await addToCart.isEnabled()) {
        await addIssue(model, "BLOKADA_DALEJ", "Wszystkie widoczne pola wybrano, ale przycisk dodania do koszyka jest nieaktywny.", { step, selected });
        return;
      }
      await verifyPrice(model, "przed dodaniem do koszyka");
      const before = await readPrice(config.selectors.price);
      await addToCart.click();
      await page.waitForLoadState("networkidle").catch(() => {});
      const cart = await readPrice(config.selectors.cartPrice);
      if (cart.value === null || cart.value <= 0) {
        await addIssue(model, "BRAK_CENY", "Brak ceny produktu w koszyku.", { beforeCart: before, cart });
      } else if (before.value !== null && Math.abs(cart.value - before.value) > 0.01) {
        await addIssue(model, "CENA_KOSZYK_ROZNA", "Cena w koszyku różni się od ceny konfiguratora.", { beforeCart: before.value, inCart: cart.value });
      }
      completed = true;
      break;
    }

    const next = page.locator(config.selectors.next).first();
    if (!await next.count() || !await next.isVisible() || !await next.isEnabled()) {
      await addIssue(model, "BLOKADA_DALEJ", "Konfigurator nie puszcza dalej mimo wybrania wszystkich dostępnych opcji.", { step, selected });
      return;
    }
    await next.click();
    await page.waitForTimeout(250);
  }

  if (!completed && results.length === issueCountBefore) {
    await addIssue(model, "BRAK_ZAKONCZENIA", `Nie osiągnięto koszyka w limicie ${config.maxSteps} kroków.`, { selected });
  }

  if (results.length === issueCountBefore) {
    results.push({ status: "OK", priority: null, type: "MODEL_OK", modelCode: model.code, modelName: model.name, selected, detectedAt: new Date().toISOString() });
  }
}

function htmlReport(items) {
  const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const rows = items.map(i => `<tr class="${i.status === "ERROR" ? "error" : "ok"}"><td>${esc(i.priority || "-")}</td><td>${esc(i.modelCode)}</td><td>${esc(i.type)}</td><td>${esc(i.message || "Test poprawny")}</td><td>${i.screenshot ? `<a href="${esc(i.screenshot)}">zrzut</a>` : "-"}</td></tr>`).join("");
  return `<!doctype html><html lang="pl"><meta charset="utf-8"><title>Raport testów Efora</title><style>body{font:15px Arial;margin:32px;color:#172a3a}table{border-collapse:collapse;width:100%}th,td{border:1px solid #bcc8ce;padding:9px;text-align:left}th{background:#172a3a;color:white}.error{background:#fce8e6}.ok{background:#e9f5ec}</style><h1>Raport automatycznych testów Efora</h1><p>Start: ${esc(startedAt)} | Koniec: ${esc(new Date().toISOString())}</p><table><thead><tr><th>Priorytet</th><th>Model</th><th>Typ</th><th>Opis</th><th>Dowód</th></tr></thead><tbody>${rows}</tbody></table></html>`;
}

try {
  await login();
  for (const model of models) {
    try { await testModel(model); }
    catch (error) { await addIssue(model, "BLAD_TECHNICZNY", error.message, { stack: error.stack }); }
  }
} finally {
  await browser.close();
  await fs.writeFile(path.join(outputDir, "report.json"), JSON.stringify({ startedAt, finishedAt: new Date().toISOString(), results }, null, 2));
  await fs.writeFile(path.join(outputDir, "report.html"), htmlReport(results));
}

const errors = results.filter(r => r.status === "ERROR").length;
console.log(`Zakończono. Modele: ${models.length}, błędy: ${errors}. Raport: results/report.html`);
process.exitCode = errors ? 1 : 0;
