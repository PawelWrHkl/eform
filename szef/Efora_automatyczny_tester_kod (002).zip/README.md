# Automatyczny tester konfiguratora Efora

Kod dla Pawła, twórcy systemu Efora. Tester działa w przeglądarce Chromium i kontroluje dwa błędy P1:

1. Brak opcji lub blokada uniemożliwiająca przejście dalej.
2. Brak ceny, cena równa zero albo cena niższa od ceny wzorcowej.

## Co Paweł musi dopasować

W `config/efora.config.json` należy wpisać adres testowej Efora i rzeczywiste selektory HTML. Najlepiej dodać do elementów stabilne atrybuty `data-testid`, zgodne z przykładową konfiguracją.

W `config/models.example.json` należy umieścić wszystkie aktywne modele. `expectedMinPrice` musi pochodzić z niezależnego, zatwierdzonego źródła, a nie z tej samej kalkulacji, którą testujemy.

## Uruchomienie

Wymagany jest Node.js 20 lub nowszy.

```bash
npm install
npm run install:browsers
EFORA_LOGIN='login_testowy' EFORA_PASSWORD='haslo_testowe' npm run test:efora
```

Login i hasło przekazujemy przez zmienne środowiskowe. Nie należy wpisywać hasła do plików projektu.

## Wyniki

Po teście powstają:

- `results/report.html` - czytelny raport;
- `results/report.json` - dane do dalszego przetwarzania;
- `results/screenshots/` - zrzuty ekranu dla każdego błędu.

Proces kończy się kodem `1`, jeżeli wykryto błąd. Dzięki temu można go podłączyć do automatycznego wdrażania i blokować publikację wersji Efora zawierającej błędy P1.

## Ważne zabezpieczenie

Tester musi działać na środowisku testowym. Zamówienia powinny być oznaczone `AUTO-TEST` i nigdy nie mogą trafić do produkcji.
